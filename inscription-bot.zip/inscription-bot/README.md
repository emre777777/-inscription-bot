# Formulaire d'inscription → Telegram

Site web avec un formulaire d'inscription (nom, prénom, email, adresse). Chaque soumission envoie une notification instantanée sur Telegram via un bot.

## 1. Créer ton bot Telegram

1. Ouvre Telegram, cherche **@BotFather**
2. Envoie `/newbot`, choisis un nom puis un username (doit finir par `bot`)
3. Copie le **token** qu'il te donne
4. Cherche **@userinfobot**, démarre-le, il te donne ton **chat_id**
5. Démarre une conversation avec TON bot (sinon il ne peut pas t'écrire)

## 2. Configuration locale

```bash
npm install
cp .env.example .env
```

Édite `.env` et remplace par tes vraies valeurs :
```
TELEGRAM_BOT_TOKEN=ton_token_ici
TELEGRAM_CHAT_ID=ton_chat_id_ici
```

## 3. Lancer en local

```bash
npm start
```

Ouvre http://localhost:3000

## 4. Déployer en ligne (gratuit)

### Option A — Render.com
1. Crée un compte sur [render.com](https://render.com)
2. "New +" → "Web Service" → connecte ton repo GitHub (ou upload direct)
3. Build command : `npm install`
4. Start command : `npm start`
5. Dans "Environment", ajoute tes variables `TELEGRAM_BOT_TOKEN` et `TELEGRAM_CHAT_ID`
6. Déploie — tu obtiens une URL publique du type `https://ton-app.onrender.com`

### Option B — Railway.app
1. Crée un compte sur [railway.app](https://railway.app)
2. "New Project" → "Deploy from GitHub repo" (ou template Node vide)
3. Ajoute les variables d'environnement dans l'onglet "Variables"
4. Railway détecte automatiquement Node.js et déploie

## Structure du projet

```
inscription-bot/
├── public/
│   └── index.html      # Page avec le formulaire
├── server.js            # Backend Express
├── package.json
├── .env.example
└── .env                 # À créer, jamais à partager/commiter
```

## Sécurité

- Le fichier `.env` contient ton token secret — ne le commit jamais sur GitHub (déjà exclu via `.gitignore`)
- Les données ne sont transmises qu'après soumission volontaire du formulaire par la personne
- Pense à ajouter une politique de confidentialité si tu utilises ça en production
