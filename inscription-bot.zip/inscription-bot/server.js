const express = require('express');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const CHAT_ID = process.env.TELEGRAM_CHAT_ID;

if (!BOT_TOKEN || !CHAT_ID) {
  console.warn('⚠️  TELEGRAM_BOT_TOKEN ou TELEGRAM_CHAT_ID manquant dans .env');
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Petite validation basique
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

app.post('/api/inscription', async (req, res) => {
  try {
    const { prenom, nom, email, adresse } = req.body;

    if (!prenom || !nom || !email || !adresse) {
      return res.status(400).json({ error: 'Champs manquants' });
    }
    if (!isValidEmail(email)) {
      return res.status(400).json({ error: 'Email invalide' });
    }

    // Échapper les caractères spéciaux Markdown de Telegram
    const esc = (str) => String(str).replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&');

    const message =
      `🆕 *Nouvelle inscription*\n\n` +
      `👤 *Prénom :* ${esc(prenom)}\n` +
      `👤 *Nom :* ${esc(nom)}\n` +
      `📧 *Email :* ${esc(email)}\n` +
      `📍 *Adresse :* ${esc(adresse)}\n\n` +
      `🕒 ${esc(new Date().toLocaleString('fr-FR'))}`;

    const telegramRes = await fetch(
      `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: CHAT_ID,
          text: message,
          parse_mode: 'MarkdownV2',
        }),
      }
    );

    if (!telegramRes.ok) {
      const errText = await telegramRes.text();
      console.error('Erreur Telegram:', errText);
      return res.status(502).json({ error: 'Erreur envoi Telegram' });
    }

    console.log(`✅ Inscription reçue : ${prenom} ${nom} (${email})`);
    res.json({ success: true });
  } catch (err) {
    console.error('Erreur serveur:', err);
    res.status(500).json({ error: 'Erreur interne' });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Serveur démarré sur http://localhost:${PORT}`);
});
